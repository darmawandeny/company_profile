<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h3><?php echo e($title); ?></h3>
			</div>
			<div class="box-body">
				<form role="form" method="POST" action="<?php echo e(url('admin/portofolio/update')); ?>">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<textarea name="keterangan" class="form-control textarea" rows="20"><?php echo $pf->keterangan; ?></textarea>
					</div>
					<button type="submit" class="btn btn-success btn-block">Update</button>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$(document).ready(function(){
		var flash = "<?php echo e(Session::has('pesan')); ?>";
		if(flash){
			var pesan = "<?php echo e(Session::get('pesan')); ?>";
			alert(pesan);
		}
	})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\companyprofile\resources\views/admin/portofolio/portofolio_edit.blade.php ENDPATH**/ ?>