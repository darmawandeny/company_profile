<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h3><?php echo e($title); ?></h3>
			</div>
			<div class="box-body">
				<form role="form" method="post" action="<?php echo e(url('admin/about')); ?>">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<textarea rows="20" name="keterangan" class="form-control textarea"><?php echo e($about->keterangan); ?></textarea>
					</div>
					<button type="submit" class="form-control btn btn-primary">Update</button>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
	$(document).ready(function(){
		var flash = "<?php echo e(Session::has('pesan')); ?>";
		if(flash){
			var pesan = "<?php echo e(Session::get('pesan')); ?>";
			alert(pesan);
		}
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\companyprofile\resources\views/admin/about/about_index.blade.php ENDPATH**/ ?>