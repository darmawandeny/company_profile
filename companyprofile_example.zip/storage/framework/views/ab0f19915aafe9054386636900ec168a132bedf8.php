<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h3><?php echo e($title); ?></h3>
			</div>
			<div class="box-body">
				<button type="button" class="btn btn-block btn-success btn-tambah">Tambah Artikel</button>
				<table class="table table-stripped">
					<thead>
						<tr>
							<th>#</th>
							<th>Judul</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($index+1); ?></td>
							<td><?php echo e($ar->judul); ?></td>
							<td><a href="<?php echo e(url('admin/artikel/'.$ar->artikel_id)); ?>" class="btn btn-primary">Edit</a><a href="<?php echo e(url('admin/artikel/delete/'.$ar->artikel_id)); ?>" class="btn btn-danger btn-hapus">Hapus</a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modal-tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        

      	<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Quick Example</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo e(url('admin/artikel')); ?>" method="POST">
            	<?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Judul</label>
                  <input type="text" name="judul" class="form-control" id="exampleInputEmail1" placeholder="Nama">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Isi</label>
                  <textarea name="isi" class="form-control textarea" rows="20"></textarea>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
         </div>


      </div>
    </div>
  </div>
</div>

<!-- Modal Hapus -->
<div class="modal fade" id="modal-hapus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        

      	<p><b><i>yakin ingin menghapus artikel ini?</i></b></p>


      </div>
      <div class="box-footer">
        <a href="" class="btn btn-primary btn-submit-hapus">Hapus</a>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$(document).ready(function(){
		var flash = "<?php echo e(Session::has('pesan')); ?>";
		if(flash){
			var pesan = "<?php echo e(Session::get('pesan')); ?>";
			alert(pesan);
		}

		$('.btn-tambah').click(function(e){
			e.preventDefault();
			$('#modal-tambah').modal();
		})

		$('body').on('click','.btn-hapus',function(e){
			e.preventDefault();
			var url = $(this).attr('href');

			$('.btn-submit-hapus').attr('href',url);

			$('#modal-hapus').modal();
		})
	})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\companyprofile\resources\views/admin/artikel/artikel_index.blade.php ENDPATH**/ ?>